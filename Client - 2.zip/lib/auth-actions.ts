import { prisma } from "./prisma";
import { hash } from "bcryptjs";

export async function registerUser(data: {
  name: string;
  email: string;
  password: string;
  role: "CLIENT" | "LAWYER";
  barRegistration?: string;
  district?: string;
  experience?: string;
}) {
  const hashedPassword = await hash(data.password, 10);

  const user = await prisma.user.create({
    data: {
      name: data.name,
      email: data.email,
      password: hashedPassword,
      role: data.role,
      barNumber: data.barRegistration,
      district: data.district,
      experience: data.experience,
    },
  });

  return user;
}
