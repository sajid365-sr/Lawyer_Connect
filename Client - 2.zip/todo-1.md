# TODO: Core Functionalities for Find Your Lawyer Platform

## ✅ 1. Login/Signup System with Clerk

- [ ] Integrate Clerk for authentication in both login and signup pages.
- [ ] Configure Clerk project and environment variables.
- [ ] Separate user data (clients) and lawyer data in the database:
  - Create `User` and `Lawyer` models in `schema.prisma`.
  - On successful registration, insert data into the appropriate collection.
- [ ] Sync Clerk user metadata with MongoDB on signup/login.
- [ ] Validate and handle edge cases (duplicate emails, invalid data, etc.).
- [ ] Create separate login signUp system for client and lawyer. SignUp field should be different for client and lawyer.
